#ifndef CONSULTA_H
#define CONSULTA_H

void consultaVendaTipo();
void consultaAlugaTipo();
void show_all();
void show_descricao();
void AluguelBairro();
void VendaBairro();
void DispCidade();
char *strlwr(char *str);
char *strupr(char *str);

#endif
